# Project Status

Last updated: 2026-05-08

## Current Stage

Early Phase 4.

The project has a strong local foundation: dependency-free Node backend, versioned configuration, lightweight runtime, admin UI, import/export, generated GTM template, basic integration docs, consistent demo data, and GPC support declaration. The next work should focus on manual GTM verification and compliance-scale features.

## Current Features

- Admin login with local cookie session.
- Editable site config stored in `data/config.json`.
- Banner editor for title, body, button text, and theme colors.
- Consent categories and Google Consent Mode v2 mapping.
- Regional Consent Mode overrides.
- Manual service list with category assignment and cookie cleanup patterns.
- Public config endpoint and automatic versioning.
- Visual config diff before publishing.
- Public site changelog generation.
- Full JSON export and import of site configuration.
- Runtime Test Lab with environment switching for production and preview.
- Generated GTM custom template bridge at `gtm/template.tpl`.
- GTM template builder in `src/server/build-gtm.js`.
- Integration guides for WordPress and Shopify.
- Basic import/export API test script in `tests/test-import-export.js`.
- GPC support declaration at `/.well-known/gpc.json`.
- Consistent site ID storage paths for active config, versions, and changelog.

## Current Local Config

- Site ID: `demo-site`
- Active production config path: `data/published/demo-site/production.json`
- Site name: `Demo Site`
- Active environment: `production`
- Active event name: `owncmp.consent_ready`
- Active version: `20260508T130000Z`
- Consent TTL: `180` days

## Completed Milestones

1. **Local MVP:** Scaffolded the dependency-free app, admin, and runtime.
2. **Operational Quality:** Added version history, rollback, visual diffs, import/export, preview mode, public changelog, and regional defaults.
3. **Integration Layer:** Built the generated GTM template, WordPress snippet guide, and Shopify guide.
4. **Maintenance:** Added documentation rules and started tracking known technical debt.

## Current Milestone In Progress

Phase 4: compliance and scale.

Current focus:

- Manually verify GTM `.tpl` import and template tests inside GTM.
- Keep status/changelog/architecture docs accurate.
- Start optional server-side consent records.

## Known Gaps

- `gtm/template.tpl` exists, but manual GTM import/test confirmation is still outstanding.
- The latest `gtm/template.tpl` was regenerated after an import failure caused by invalid export section names and field/permission serialization.
- There is no server-side consent record storage yet.
- Accessibility and performance audits have not been completed.
- Local JSON storage is still prototype-grade.

## Recommended Next Steps

1. Manually import `gtm/template.tpl` into GTM and record the result in `docs/gtm-verification.md`.
2. Add optional server-side consent record storage.
3. Add accessibility and performance audits for the banner/runtime.
4. Decide when to replace local JSON storage with a database.

## Documentation Rule

Every meaningful project change must update documentation in the same work session.

At minimum:

- Update `docs/status.md` when project state, features, or next steps change.
- Update `docs/changelog.md` when files or behavior change.
- Update `README.md` when setup, usage, or major capabilities change.
- Update architecture or roadmap docs when technical direction changes.
